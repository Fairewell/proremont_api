const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const crypto = require('crypto');
require('dotenv').config(); // Для загрузки переменных окружения

const app = express();
const PORT = 51599;

// Чтение секретных ключей из файла
const secretKeys = JSON.parse(fs.readFileSync('secret_keys.json', 'utf8'));

// Используем фиксированный ключ и вектор инициализации (IV)
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY; // Должен быть 32 байта
const IV = process.env.IV; // Должен быть 16 байтов

// Функция для шифрования
function encrypt(text) {
    const algorithm = 'aes-256-cbc';
    const cipher = crypto.createCipheriv(algorithm, Buffer.from(ENCRYPTION_KEY), Buffer.from(IV));
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

// Функция для расшифрования
function decrypt(text) {
    const algorithm = 'aes-256-cbc';
    const decipher = crypto.createDecipheriv(algorithm, Buffer.from(ENCRYPTION_KEY, 'hex'), Buffer.from(IV, 'hex'));
    let decrypted = decipher.update(text, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

// Middleware для парсинга JSON
app.use(bodyParser.json());

// Эндпоинт для проверки токена
app.post('/check-token', (req, res) => {
    const { secretToken } = req.body;

    // Проверка наличия токена
    if (!secretToken || !secretToken.encryptedData || !secretToken.iv) {
        return res.status(400).json({ message: 'Токен не предоставлен или неполный' });
    }

    // Проверяем каждый секретный ключ
    for (const key of secretKeys) {
        try {
            const decryptedString = decrypt(secretToken.encryptedData);
            if (decryptedString === key.secretstring) {
                return res.status(200).json({ message: 'Доступ разрешен', user: key.name });
            }
        } catch (error) {
            console.error('Ошибка при расшифровке:', error);
            return res.status(500).json({ message: 'Ошибка сервера' });
        }
    }

    return res.status(403).json({ message: 'Доступ запрещен' });
});

const server = app.listen(PORT, () => {
    const addressInfo = server.address(); // Адрес сервера
    console.log(`Сервер слушает на адресе ${addressInfo.address} и порту ${addressInfo.port} в режиме ${app.settings.env}`);
});